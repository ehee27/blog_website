












/* define variable for all sections and list items */
const sections = document.querySelectorAll('section');
const navLi = document.querySelectorAll('nav .container ul li');

/* set scroll event listener */
window.addEventListener('scroll', ()=> {
  let current = '';

/* set the current position base off the Y axis */
  sections.forEach(section => {
    const sectionTop = section.offsetTop;
    const sectionHeight = section.clientHeight;
    if(scrollY > sectionTop) {
      current = section.getAttribute('id');
    }
  })
  navLi.forEach (li => {
    li.classList.remove('active');
    if(li.classList.contains(current)){
      li.classList.add('active')
    }
  })
})
