// Manipulate ClassList in Nav & Sections to highlight ACTIVE
// 1.  Define variable Nav LIST ITEMS and SECTIONS
const navLi = document.querySelectorAll('nav .container ul li');
const sections = document.querySelectorAll('section');

// 2. Set Event listener & CURRENT POSITION VARIABLE
window.addEventListener('scroll', ()=> {
  let current = '';

// 3. Track SECTIONS based off their Y axis
  sections.forEach(section => {
    const sectionTop = section.offsetTop;
    const sectionHeight = section.clientHeight;

// 4. Re-define the 'CURRENT' variable based off Y scroll
    if(scrollY >= (sectionTop - sectionHeight / 3)) {
      current = section.getAttribute('id');
    }
  })

// 5. Modify ACTIVE status on ClassLists
  navLi.forEach (li => {
    li.classList.remove('active');
    if(li.classList.contains(current)){
      li.classList.add('active')
    }
  })
  sections.forEach (section => {
    section.classList.remove('active');
    if(section.classList.contains(current)){
      section.classList.add('active')
    }
  })
})

// Scroll to Top Button 
// 1. Tag Button & Root Element
const scrollToTopBtn = document.getElementById('scrollToTopBtn');
const rootElement = document.documentElement;

// 2. Set scroll Location function based off Y axis
  function scrollLoc() {
    const scrollTotal = rootElement.scrollHeight - rootElement.clientHeight;

// 3. Display the button if more than 80% scroll
    if ((rootElement.scrollTop / scrollTotal ) > 0.80 ) {
      scrollToTopBtn.classList.add('showBtn')
    } else {
      scrollToTopBtn.classList.remove('showBtn')
    }
  }
// 4. Add the Event Listener to the document & trigger Scroll Location
document.addEventListener('scroll', scrollLoc);

// 5. Define the scrollToTop functionality 
  function scrollToTop() {
    rootElement.scrollTo({
      top: 0,
      behavior: 'smooth'
    })
  }
// 6. Set Event click on button & Trigger scrollToTop
scrollToTopBtn.addEventListener('click', scrollToTop);




/***********   */

/* DOM Elements 
// define variable for all list items
const navLi = document.querySelectorAll('nav .container ul li');

const pageName = document.getElementById('new_page');

function getPageName() {
  if(localStorage.getItem('pageName') === null) {
    pageName.textContent = '[PAGE NAME]';
  } else {
    pageName.textContent = localStorage.getItem('pageName');
  }
}

// Function: Create a New Nav Item and Section
function createPage () {
}

/* Nav Item
    const newNav = document.createElement('li');
    newNav.innerHTML = '<li class="New Section"><a href="#new-section">New Section</a></li';

/ Page Section
    const newSect = document.createElement('section');
    newSect.innerHTML = '<section id="section-home"><h1>NEW SECTION</h1><br><p><b>Lorem ipsum dolor</b> sit amet consectetur adipisicing elit. Veniam earum ab deleniti corporis eius aut sequi sapiente voluptatem provident animi culpa fuga repudiandae doloremque dignissimos laboriosam error mollitia beatae aliquid, possimus harum. Velit, adipisci dolores!</p><br><em>Lorem ipsum dolor</b> sit amet, consectetur adipisicing elit. Ad, sint.</em></p></section>';

// Select the parent Nav menu
    const navList = document.getElementById('nav-list');
    navList.appendChild(newNav);
    const content = document.getElementById('content');
    content.appendChild(newSect);
    console.log('Nav added');
}

// Tag the Nav section with Click Event
const newPage = document.getElementById('new_page');
newPage.addEventListener('click', createPage);*/
