const sections = document.querySelectorAll('section');
const Li = document.querySelectorAll('.links');

function activeMenu() {
  let len = sections.length;
  while(--len && window.scrollY + 97 < sections[len].offsetTop){}
  Li.forEach(ltx => ltx.classList.remove('active'));
  Li[len].classList.add('active');
}
activeMenu();
window.addEventListener('scroll', activeMenu);